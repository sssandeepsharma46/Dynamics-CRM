﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DNLB.Common
{
    public class MetaData
    {
        public class Student
        {
            public const string EntityLogicalName = "dnlb_student";
            public const string FirstName = "dnlb_firstname";
            public const string LastName = "dnlb_lastname";
        }
    }
}
