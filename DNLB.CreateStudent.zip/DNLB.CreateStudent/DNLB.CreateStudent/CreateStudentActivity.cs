﻿namespace DNLB.CreateStudent
{
    using DNLB.Common;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Workflow;
    using System;
    using System.Activities;

    /// <summary>
    /// Defines the <see cref="CreateStudentActivity" />.
    /// </summary>
    public class CreateStudentActivity : CodeActivity
    {
        /// <summary>
        /// Gets or sets the FirstName.
        /// </summary>
        [Input("First Names From Custom"), RequiredArgument]
        public InArgument<string> FirstName { get; set; }

        /// <summary>
        /// Gets or sets the LastName.
        /// </summary>
        [Input("Last Name From Custom")]
        public InArgument<string> LastName { get; set; }

        /// <summary>
        /// Defines the crmService.
        /// </summary>
        internal IOrganizationService crmService = null;

        /// <summary>
        /// Defines the tracingService.
        /// </summary>
        internal ITracingService tracingService = null;

        //Organization Service - Create update, delete retrei, merge, 
        //Tracing Service - create logs
        /// <summary>
        /// The Execute.
        /// </summary>
        /// <param name="exectioncontext">The exectioncontext<see cref="CodeActivityContext"/>.</param>
        protected override void Execute(CodeActivityContext exectioncontext)
        {
            IWorkflowContext context = exectioncontext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = exectioncontext.GetExtension<IOrganizationServiceFactory>();
            crmService = serviceFactory.CreateOrganizationService(context.UserId);
            tracingService = exectioncontext.GetExtension<ITracingService>();

            if (crmService == null)
            {
                tracingService.Trace($"CRM Service is not initialized.");
                return;
            }
            try
            {
                string firstName = FirstName.Get(exectioncontext);
                string lastName = LastName.Get(exectioncontext);
                tracingService.Trace($"FirstName : {firstName} & LastName : {lastName}");

                if (string.Equals(firstName, "sandy"))
                {
                    tracingService.Trace($"You can not create Student with {firstName}");
                    throw new InvalidPluginExecutionException($"You can not create Student with {firstName}");
                }
                CreateStudent(firstName, lastName);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message, ex);
            }
        }

        /// <summary>
        /// The CreateStudent.
        /// </summary>
        /// <param name="fname">The fname<see cref="string"/>.</param>
        /// <param name="lname">The lname<see cref="string"/>.</param>
        private void CreateStudent(string fname, string lname)
        {
            tracingService.Trace($"Proceeding to Create Student");
            Entity createStudent = new Entity(MetaData.Student.EntityLogicalName);
            createStudent[MetaData.Student.FirstName] = fname;
            createStudent[MetaData.Student.LastName] = lname;
            crmService.Create(createStudent);
            tracingService.Trace($"End of Creating Student");
        }
    }
}
