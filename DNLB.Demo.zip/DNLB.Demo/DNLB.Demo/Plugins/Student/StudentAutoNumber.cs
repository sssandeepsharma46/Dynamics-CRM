﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace DNLB.Demo.Plugins.Student
{
    public class StudentAutoNumber : IPlugin
    {
        private readonly object lockObject;
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService crmService = serviceFactory.CreateOrganizationService(context.UserId);

            if(crmService == null)
            {
                tracingService.Trace($"CRM is not found.");
                return;
            }           

            if(context.Stage != 20)
            {
                tracingService.Trace($"Plugin is not registered on Pre-Operation");
                return;
            }

            if(context.Depth > 3)
            {
                tracingService.Trace($"Depth is {context.Depth}");
                return; 
            }

            if(context.MessageName.ToLower() != "create")
            {
                tracingService.Trace($"Plugin is not registred on Create");
                return;
            }
            
            if(context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity studentTarget = context.InputParameters["Target"] as Entity;
                if(studentTarget.LogicalName.ToLower() != "dnlb_student")
                {
                    tracingService.Trace("Plugin is not registered on Student.");
                    return;
                }

                studentTarget["dnlb_name"] = GetAutoNumber(crmService, tracingService, "studentautonumber");
            }
        }

        private string GetAutoNumber(IOrganizationService service, ITracingService tracingService, string autoNumberName)
        {
            string autoNumber = string.Empty;
            QueryExpression qeAutoNumberConfiguration = new QueryExpression()
            {
                EntityName = "dnlb_autonumberconfiguration",
                TopCount = 1,
                ColumnSet = new ColumnSet("dnlb_prefix", "dnlb_suffix", "dnlb_seperator", "dnlb_currentnumber"),
            };
            lock (lockObject)
            {
                EntityCollection ecStudentConfiguration = service.RetrieveMultiple(qeAutoNumberConfiguration);
                if (ecStudentConfiguration.Entities.Count > 0)
                {
                    Entity studentAutoNumberConfig = ecStudentConfiguration.Entities[0];
                    string prefix = string.Empty, suffix = string.Empty, seperator = string.Empty, currentNumber = string.Empty;
                    int currentNum;
                    if (studentAutoNumberConfig.Contains("dnlb_prefix"))
                    {
                        prefix = studentAutoNumberConfig.GetAttributeValue<string>("dnlb_prefix");
                    }
                    if (studentAutoNumberConfig.Contains("dnlb_suffix"))
                    {
                        suffix = studentAutoNumberConfig.GetAttributeValue<string>("dnlb_suffix");
                    }
                    if (studentAutoNumberConfig.Contains("dnlb_seperator"))
                    {
                        seperator = studentAutoNumberConfig.GetAttributeValue<string>("dnlb_seperator");
                    }
                    if (studentAutoNumberConfig.Contains("dnlb_currentnumber"))
                    {
                        currentNumber = studentAutoNumberConfig.GetAttributeValue<string>("dnlb_currentnumber");
                    }
                    if (!string.IsNullOrEmpty(currentNumber))
                    {
                        currentNum = Convert.ToInt32(currentNumber);
                        currentNum++;
                        currentNumber = currentNum.ToString();
                    }
                    studentAutoNumberConfig["dnlb_currentnumber"] = currentNumber;
                    service.Update(studentAutoNumberConfig);

                    autoNumber = prefix + seperator + suffix + currentNumber;
                }          
            }
            return autoNumber;
        }
    }
}
