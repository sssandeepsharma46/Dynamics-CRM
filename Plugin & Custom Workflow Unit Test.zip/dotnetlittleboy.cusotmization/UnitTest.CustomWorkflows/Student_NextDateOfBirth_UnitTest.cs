﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FakeXrmEasy;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Collections.Generic;
using dotnetlittleboy.cusotmization.CustomWorkflow;

namespace UnitTest.CustomWorkflows
{
    [TestClass]
    public class Student_NextDateOfBirth_UnitTest
    {
        [TestMethod]
        public void NoneLeap_CorrectDOB()
        {
            //Initialize variables
            var fakeContext = new XrmFakedContext();
            var service = fakeContext.GetOrganizationService();

            //Studnet mock record
            var studentEntity = new Entity("dnlb_student");
            studentEntity.Attributes.Add("dnlb_dateofbirth", new DateTime(1991, 11, 10));
            Guid studentId = service.Create(studentEntity);

            EntityReference studentRef = new EntityReference(studentEntity.LogicalName, studentId);

            var inputs = new Dictionary<string, object> { { "Student", studentRef } };

            fakeContext.ExecuteCodeActivity<Student_NextDateOfBirth>(inputs, null);
            Entity updatedStudent = service.Retrieve(studentEntity.LogicalName, studentId, new ColumnSet("dnlb_nextdateofbirth"));

            Assert.AreEqual(updatedStudent.GetAttributeValue<DateTime>("dnlb_nextdateofbirth"), new DateTime(2021, 11, 10));
        }
        [TestMethod]
        public void IncorrectDOB_YearGTCurrentYear()
        {
            //Initialize variables
            var fakeContext = new XrmFakedContext();
            var service = fakeContext.GetOrganizationService();

            //Studnet mock record
            var studentEntity = new Entity("dnlb_student");
            studentEntity.Attributes.Add("dnlb_dateofbirth", new DateTime(2021, 11, 10));
            Guid studentId = service.Create(studentEntity);

            EntityReference studentRef = new EntityReference(studentEntity.LogicalName, studentId);

            var inputs = new Dictionary<string, object> { { "Student", studentRef } };

            Assert.ThrowsException<InvalidPluginExecutionException>(() =>
            {
                var output = fakeContext.ExecuteCodeActivity<Student_NextDateOfBirth>(inputs, null);
            });


        }
    }
}
