using Microsoft.Xrm.Sdk;
using System;
using Microsoft.Xrm.Sdk.Query;
using Twilio.Types;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace Send_SMS_Demo
{
    /// <summary>
    /// Plugin development guide: https://docs.microsoft.com/powerapps/developer/common-data-service/plug-ins
    /// Best practices and guidance: https://docs.microsoft.com/powerapps/developer/common-data-service/best-practices/business-logic/
    /// </summary>
    public class SendSMSTwilio : PluginBase
    {
        public SendSMSTwilio(string unsecureConfiguration, string secureConfiguration)
            : base(typeof(SendSMSTwilio))
        {
            // TODO: Implement your custom configuration handling
            // https://docs.microsoft.com/powerapps/developer/common-data-service/register-plug-in#set-configuration-data
        }

        // Entry point for custom business logic execution
        protected override void ExecuteDataversePlugin(ILocalPluginContext localPluginContext)
        {
            if (localPluginContext == null)
            {
                throw new ArgumentNullException(nameof(localPluginContext));
            }

            var context = localPluginContext.PluginExecutionContext;
            if(context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference contactEntityReference)
            {
                if(contactEntityReference.LogicalName == "contact")
                {
                    var serviceFactory = localPluginContext.OrgSvcFactory;
                    var crmService = serviceFactory.CreateOrganizationService(context.UserId);
                    Entity contactRecord = crmService.Retrieve(contactEntityReference.LogicalName, contactEntityReference.Id, new ColumnSet("mobilephone"));
                    if (contactRecord.Contains("mobilephone"))
                    {
                        string mobileNumber = "+91"+contactRecord.GetAttributeValue<string>("mobilephone");
                        SendSMSFromTwilio(mobileNumber);
                    }
                }
                else
                {
                    localPluginContext.Trace($"Your plugin is not registered on contact, hence aborting");
                }
            }
        }

        private void SendSMSFromTwilio(string mobileNumber)
        {
            string accountSid = "";
            string authToken = "";

            TwilioClient.Init(accountSid, authToken);
            // Define the message parameters
            var toPhoneNumber = new PhoneNumber(mobileNumber);  // Replace with the recipient's phone number
            var fromPhoneNumber = new PhoneNumber("+12602055499");  // Replace with your Twilio number
            var messageBody = "Hello! This is a test message from Dynamics 365 plugin.";

            // Send the message
            var message = MessageResource.Create(
                body: messageBody,
                from: fromPhoneNumber,
                to: toPhoneNumber
            );
        }
    }
}
