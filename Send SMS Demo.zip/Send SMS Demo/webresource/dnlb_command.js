﻿if (typeof (dnlb) === 'undefined') {
    dnlb = {
        __namespace: true
    };
}

if (typeof (dnlb.command) === 'undefined') {
    dnlb.command = {};
}

dnlb.command.contact = (function () {
    // Function to send SMS to selected contacts
    var sendSMS = function (primaryControl) {
        const subgridControl = primaryControl.getControl("ContactsSubgrid"); // Replace with actual subgrid name

        if (subgridControl) {
            const selectedItems = subgridControl.getGrid().getSelectedRows();
            const selectedCount = selectedItems.getLength();

            if (selectedCount === 0) {
                // Show alert if no contact is selected
                const alertStrings = { text: "No contacts have been selected. Please select at least one contact to send an SMS." };
                const alertOptions = { height: 150, width: 400 };
                Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                return; // Exit the function if no contacts are selected
            }

            console.log("Number of selected contacts: " + selectedCount);

            // Show confirmation dialog if contacts are selected
            const confirmOptions = { height: 200, width: 450 };
            const confirmStrings = {
                text: `You have selected ${selectedCount} contact(s). Are you sure you want to send SMS?`,
                title: "Confirm SMS Sending"
            };

            Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
                function (success) {
                    if (success.confirmed) {
                        console.log("User confirmed to send SMS.");

                        // Loop through each selected contact and send SMS
                        selectedItems.forEach(row => {
                            var contactId = row.getData().getEntity().getId();
                            contactId = contactId.replace("{", "").replace("}", "");
                            console.log(`Sending SMS for contact ID: ${contactId}`);

                            var req = new XMLHttpRequest();
                            req.open("POST", Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/contacts(" + contactId + ")/Microsoft.Dynamics.CRM.dnlb_SendSMSUsingTwilio", true);
                            req.setRequestHeader("OData-MaxVersion", "4.0");
                            req.setRequestHeader("OData-Version", "4.0");
                            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                            req.setRequestHeader("Accept", "application/json");
                            req.onreadystatechange = function () {
                                if (this.readyState === 4) {
                                    req.onreadystatechange = null;
                                    if (this.status === 200 || this.status === 204) {
                                        console.log("SMS sent successfully for contact ID: " + contactId);
                                    } else {
                                        console.log("Error sending SMS for contact ID: " + contactId + ": " + this.responseText);
                                    }
                                }
                            };
                            req.send();
                        });
                    } else {
                        console.log("User canceled the SMS sending.");
                    }
                },
                function (error) {
                    console.log("Error in confirmation dialog: " + error.message);
                }
            );
        } else {
            console.log("Subgrid not found");
        }
    };

    // Expose the sendSMS function
    return {
        sendSMS: sendSMS
    };
})();
//dnlb.command.contact.sendSMS
