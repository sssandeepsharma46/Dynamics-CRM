﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Office.Interop.Excel;
using System.Threading.Tasks;

namespace Dynamics365ConsoleApp
{
    internal class ImportFromExcelFile
    {
        public void ImportFile()
        {
            #region Part 1 : Creating CRM Service Client
            // Initialize D365 connection
            string clientId = "619cfe90-e7c9-4e2e-b61f-ab68a59e4108";
            string clientSecret = "8hr8Q~Q4jQNtbWnbN_~06EtjcvNYcnAYZ7~r5cIn";
            string authority = "https://login.microsoftonline.com/97283a5a-0c21-4b0c-977e-415c3a952480";
            string crmURL = "https://dnlb53.crm.dynamics.com";

            string connString = $"AuthType=ClientSecret;Url={crmURL};ClientId={clientId};ClientSecret={clientSecret};Authority={authority};RequireNewInstance=True;";
            CrmServiceClient serviceClient = new CrmServiceClient(connString);

            if (serviceClient.IsReady)
            {
                Console.WriteLine($"CRM Connection Successfull");
            }
            #endregion

            #region Part 2: Loading the workbook from Excel file table
            // Open the Excel file
            var excelApp = new Application();
            var workbook = excelApp.Workbooks.Open(@"C:\Users\sandsharma\Desktop\Sandy\personal\D365 Training\demo import\dnlb.console.import.demo1\dnlb.console.import.demo1\1Import Test.xlsx");
            var worksheet = (Worksheet)workbook.Sheets[1];
            #endregion

            #region Part 3: Initialize Template and Async Task List
            // Read data from Excel
            List<ExcelDataTemplate> excelData = ReadExcelData(worksheet);

            // Batch size for bulk creation
            int batchSize = 1000;

            // Create a list to store tasks for parallel execution
            var tasks = new List<Task>();
            #endregion

            #region Part 4: Loop through all the records loaded from excel file
            for (int startIndex = 0; startIndex < excelData.Count; startIndex += batchSize)
            {
                // Get a batch of data
                List<ExcelDataTemplate> batch = excelData.Skip(startIndex).Take(batchSize).ToList();

                // Create a new task for each batch
                var task = Task.Run(() =>
                {
                    try
                    {
                        // Create entities for the batch
                        var entities = batch.Select(MapToD365Entity).ToList();

                        // Create and execute multiple requests
                        ExecuteMultipleCreateRequests(serviceClient, entities);
                    }
                    catch (Exception ex)
                    {
                        // Handle errors and log them
                        Console.WriteLine($"Error creating records: {ex.Message}");
                    }
                });

                tasks.Add(task);
            }
            #endregion

            #region Part 5: Close the application and releae object
            // Wait for all tasks to complete
            Task.WhenAll(tasks).Wait();

            // Close Excel and release resources
            workbook.Close(false);
            excelApp.Quit();
            ReleaseObject(worksheet);
            ReleaseObject(workbook);
            ReleaseObject(excelApp);
            Console.WriteLine("Data import completed.");
            #endregion
        }

        #region ReadExcelData
        static List<ExcelDataTemplate> ReadExcelData(Worksheet worksheet)
        {
            List<ExcelDataTemplate> data = new List<ExcelDataTemplate>();

            // Assuming 'Name' is in column A and 'FullName' is in column B
            int rowCount = worksheet.UsedRange.Rows.Count;

            for (int row = 2; row <= rowCount; row++)
            {
                var name = ((Range)worksheet.Cells[row, 1]).Value2?.ToString();
                var fullName = ((Range)worksheet.Cells[row, 2]).Value2?.ToString();

                if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(fullName))
                {
                    var excelData = new ExcelDataTemplate
                    {
                        Name = name,
                        FullName = fullName
                    };
                    data.Add(excelData);
                }
            }

            return data;
        }
        #endregion

        #region MapToD365Entity
        static Entity MapToD365Entity(ExcelDataTemplate excelData)
        {
            Entity entity = new Entity("dotnet_importtest");

            entity["dotnet_name"] = excelData.Name;
            entity["dotnet_fullname"] = excelData.FullName;

            return entity;
        }
        #endregion

        #region ReleaseObject
        static void ReleaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
            }
            catch
            {
                throw new Exception("$ReleaseObject Exception");
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion

        #region ExecuteMultipleCreateRequests
        static void ExecuteMultipleCreateRequests(IOrganizationService service, List<Entity> entities)
        {
            var multipleRequest = new ExecuteMultipleRequest
            {
                Settings = new ExecuteMultipleSettings
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },
                Requests = new OrganizationRequestCollection()
            };

            foreach (var entity in entities)
            {
                var createRequest = new CreateRequest { Target = entity };
                multipleRequest.Requests.Add(createRequest);
            }

            var multipleResponse = (ExecuteMultipleResponse)service.Execute(multipleRequest);

            foreach (var responseItem in multipleResponse.Responses)
            {
                if (responseItem.Response is CreateResponse createResponse)
                {
                    Console.WriteLine($"Created record with ID: {createResponse.id}");
                }
                else if (responseItem.Fault != null)
                {
                    Console.WriteLine($"Error: {responseItem.Fault.Message}");
                }
            }
        }
        #endregion
    }

    class ExcelDataTemplate
    {
        public string Name { get; set; }
        public string FullName { get; set; }
    }
}
