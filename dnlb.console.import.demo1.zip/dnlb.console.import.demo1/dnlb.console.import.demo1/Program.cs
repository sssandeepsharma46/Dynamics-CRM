﻿using System;
using System.Collections.Generic;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;
using OfficeOpenXml;
using OfficeOpenXml.Core.ExcelPackage;

namespace Dynamics365ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create object of ImportFromExcelFile class.
            ImportFromExcelFile importFromExcelFile = new ImportFromExcelFile();
            importFromExcelFile.ImportFile();

            Console.WriteLine("Data import completed.");
        }

    }
}