﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Tooling;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;

namespace dnlb.demo.console
{
    class Program
    {
        static void Main(string[] args)
        {
            string clientId = "da113276-f9ea-4908-89f4-9fd3c40062ed";
            string clientSecret = "Dp88Q~SdLFyCWwZQPrEvfVarF25w23-LJ9~vzdoj";
            string authority = "https://login.microsoftonline.com/97283a5a-0c21-4b0c-977e-415c3a952480";
            string crmURl = "https://dnlb53.crm.dynamics.com/";

            string conString = $"AuthType=ClientSecret;Url={crmURl};Clientid={clientId};ClientSecret={clientSecret};Authority={authority};RequirenNewInstance=True;";

            CrmServiceClient crmService = new CrmServiceClient(conString);
            if (crmService.IsReady)
            {
                Console.WriteLine("CRM Connected Successfully");
            }
            else
            {
                Console.WriteLine($"CRM Connection failed");
            }

            Console.ReadLine();

        }
    }
}
