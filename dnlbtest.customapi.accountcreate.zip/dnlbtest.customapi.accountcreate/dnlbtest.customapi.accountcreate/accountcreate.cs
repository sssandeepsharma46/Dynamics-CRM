﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace dnlbtest.customapi.accountcreate
{
    public class accountcreate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IOrganizationService crmService = null;
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            if (context.MessageName.Equals("dnlb_accoountname"))
            {
                try
                {
                    IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                    crmService = serviceFactory.CreateOrganizationService(context.UserId);
                    
                    //Retrieve input parameter
                    string accountName = (string)context.InputParameters["accountname"];
                    string accountId = (string)context.InputParameters["parentaccountid"];

                    Entity createAccount = new Entity("account");
                    createAccount["name"] = accountName;
                    createAccount["parentaccountid"] = new EntityReference("account", Guid.Parse(accountId));

                    Guid accId = crmService.Create(createAccount);

                    context.OutputParameters["apiresponse"] = accId.ToString();

                }
                catch (Exception)
                {
                    throw new NotImplementedException();
                }
               
            }
            
        }
    }
}
