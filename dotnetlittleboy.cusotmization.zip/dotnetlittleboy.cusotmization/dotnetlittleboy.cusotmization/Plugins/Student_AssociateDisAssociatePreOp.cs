﻿namespace dotnetlittleboy.cusotmization.Plugins
{
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Query;
    using System;

    /// <summary>
    /// Defines the <see cref="Student_AssociateDisAssociatePreOp" />.
    /// </summary>
    public class Student_AssociateDisAssociatePreOp : IPlugin
    {
        /// <summary>
        /// The Execute.
        /// </summary>
        /// <param name="serviceProvider">The serviceProvider<see cref="IServiceProvider"/>.</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                EntityReference targetEntity = null;
                EntityReference relatedEntity = null;
                string relationshipname = string.Empty;
                Entity studentEntity = null;
                Entity classEntity = null;
                Entity courseEntity = null;

                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference)
                {
                    targetEntity = context.InputParameters["Target"] as EntityReference;
                }
                if (context.InputParameters.Contains("Relationship"))
                {
                    relationshipname = ((Relationship)context.InputParameters["Relationship"]).SchemaName;
                }
                if (relationshipname != "dnlb_dnlb_student_dnlb_class")
                {
                    return;
                }
                if (context.InputParameters.Contains("RelatedEntities") && context.InputParameters["RelatedEntities"] is EntityReferenceCollection)
                {
                    EntityReferenceCollection relatedEntityCol = context.InputParameters["RelatedEntities"] as EntityReferenceCollection;
                    relatedEntity = relatedEntityCol[0];
                }
                studentEntity = service.Retrieve(targetEntity.LogicalName, targetEntity.Id, new ColumnSet("dnlb_courseappliedfor", "dnlb_subsidy", "dnlb_tax", "dnlb_totalfee", "dnlb_universityfee"));
                classEntity = service.Retrieve(relatedEntity.LogicalName, relatedEntity.Id, new ColumnSet("dnlb_courseid"));
                courseEntity = service.Retrieve("dnlb_course", classEntity.GetAttributeValue<EntityReference>("dnlb_courseid").Id, new ColumnSet("dnlb_basicfee"));

                //Check if the plugin is registered for Associate
                if (context.MessageName.ToLower() == "associate")
                {
                    if (studentEntity.GetAttributeValue<EntityReference>("dnlb_courseappliedfor").Id != classEntity.GetAttributeValue<EntityReference>("dnlb_courseid").Id)
                    {
                        throw new Exception("The student is not applied for this course or class");
                    }
                    Money subsity = studentEntity.GetAttributeValue<Money>("dnlb_subsidy") == null ? new Money(0) : studentEntity.GetAttributeValue<Money>("dnlb_subsidy");
                    Money tax = studentEntity.GetAttributeValue<Money>("dnlb_tax") == null ? new Money(0) : studentEntity.GetAttributeValue<Money>("dnlb_tax");
                    Money university = studentEntity.GetAttributeValue<Money>("dnlb_universityfee") == null ? new Money(0) : studentEntity.GetAttributeValue<Money>("dnlb_universityfee");
                    Money basefee = courseEntity.GetAttributeValue<Money>("dnlb_basicfee") == null ? new Money(0) : courseEntity.GetAttributeValue<Money>("dnlb_basicfee");
                    Entity updateStudent = new Entity(targetEntity.LogicalName);
                    updateStudent.Id = targetEntity.Id;
                    updateStudent["dnlb_basicfee"] = new Money(basefee.Value);
                    updateStudent["dnlb_subsidy"] = new Money(subsity.Value);
                    updateStudent["dnlb_tax"] = new Money(tax.Value);
                    updateStudent["dnlb_universityfee"] = new Money(university.Value);
                    updateStudent["dnlb_totalfee"] = new Money(basefee.Value + university.Value + tax.Value - subsity.Value);
                    service.Update(updateStudent);

                }
                else if (context.MessageName.ToLower() == "disassociate")
                {
                    Money basefee = courseEntity.GetAttributeValue<Money>("dnlb_basicfee") == null ? new Money(0) : courseEntity.GetAttributeValue<Money>("dnlb_basicfee");
                    Money totalfee = studentEntity.GetAttributeValue<Money>("dnlb_totalfee") == null ? new Money(0) : studentEntity.GetAttributeValue<Money>("dnlb_totalfee");
                    Entity updateStudent = new Entity(targetEntity.LogicalName);
                    updateStudent.Id = targetEntity.Id;
                    updateStudent["dnlb_basicfee"] = new Money(0);
                    updateStudent["dnlb_totalfee"] = new Money(totalfee.Value - basefee.Value);
                    service.Update(updateStudent);
                }

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
                throw;
            }
        }
    }
}
