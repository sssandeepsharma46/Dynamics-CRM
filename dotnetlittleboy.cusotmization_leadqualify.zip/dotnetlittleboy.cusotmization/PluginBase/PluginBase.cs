﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using System.Globalization;

namespace dotnetlittleboy.cusotmization.PluginBase
{
    public abstract class PluginBase : IPlugin
    {
        internal string pluginClassName { get; set; }

        public PluginBase(Type pluginName)
        {
            this.pluginClassName = pluginName.ToString();
        }

        protected class LocalPLuginExecution
        {
            internal IServiceProvider serviceProvider { get; set; }
            internal IOrganizationServiceFactory serviceFactory { get; set; }
            internal IOrganizationService orgService { get; set; }
            internal IPluginExecutionContext pluginContext { get; set; }
            internal ITracingService tracingService { get; set; }

            public LocalPLuginExecution(IServiceProvider serviceProvider)
            {
                if (serviceProvider == null)
                {
                    throw new InvalidPluginExecutionException("Invalid Service Provider");
                }
                this.pluginContext = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                this.serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                this.orgService = this.serviceFactory.CreateOrganizationService(this.pluginContext.UserId);
                this.tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            }

            public void TraceMessage(string message)
            {
                if (string.IsNullOrWhiteSpace(message))
                {
                    return;
                }
                if (this.pluginContext == null)
                {
                    this.tracingService.Trace("Invalid Plugin execution context");
                }
                else
                {
                    this.tracingService.Trace(string.Format(CultureInfo.InvariantCulture, "CorrelationId : {0}, UserId: {1}, message: {2}", this.pluginContext.CorrelationId, this.pluginContext.UserId, message));
                }
            }

        }
        public void Execute(IServiceProvider serviceProvider)
        {
            if (serviceProvider == null)
            {
                throw new InvalidPluginExecutionException("Service Provider is not initialized correctly.");
            }
            LocalPLuginExecution localPluginExecution = new LocalPLuginExecution(serviceProvider);
            localPluginExecution.TraceMessage(string.Format(CultureInfo.InvariantCulture, "Entered in {0}.Execute() method.", this.pluginClassName));
            try
            {
                ExecutePluginLogic(localPluginExecution);
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
            finally
            {
                localPluginExecution.TraceMessage(string.Format(CultureInfo.InvariantCulture, "Exit {0}.Execute() method.", this.pluginClassName));
            }
        }

        //virutal method
        protected virtual void ExecutePluginLogic(LocalPLuginExecution localPluginExecution)
        {
            //Plugin logic will be written in derived plugin class by overriding this method.
        }
    }
}
