﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using System.Globalization;

namespace dotnetlittleboy.cusotmization.Plugins
{
    using PluginBase;
    public class LeadQualifyPlugin : PluginBase
    {
        //constructor
        public LeadQualifyPlugin() : base(typeof(LeadQualifyPlugin))
        {
            //constructor implementation here
        }

        protected override void ExecutePluginLogic(LocalPLuginExecution localPluginExecution)
        {
            if (localPluginExecution == null)
            {
                throw new InvalidPluginExecutionException("Invalid local plugin exectuion object.");

            }
            try
            {
                //IPlugin components
                IPluginExecutionContext context = localPluginExecution.pluginContext;
                IOrganizationService crmService = localPluginExecution.orgService;

                if (context.InputParameters.Contains("LeadId") && context.InputParameters["LeadId"] is EntityReference)
                {
                    if (context.MessageName.ToLower() != "qualifylead" && context.Stage != 20) { return; }
                    EntityReference leadRef = (EntityReference)context.InputParameters["LeadId"];

                    Entity leadEntity = crmService.Retrieve(leadRef.LogicalName, leadRef.Id, new ColumnSet("leadsourcecode"));
                    if (leadEntity != null && leadEntity.Contains("leadsourcecode"))
                    {
                        if (leadEntity.GetAttributeValue<OptionSetValue>("leadsourcecode").Value == 8)//lead source is web
                        {
                            context.InputParameters["CreateAccount"] = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}
